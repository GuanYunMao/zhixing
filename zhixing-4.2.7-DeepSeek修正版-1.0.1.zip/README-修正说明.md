# 知行 4.2.7 侧栏扩展 · DeepSeek 结果修正版

> 这是对 DeepSeek 给出的 1.0.0 结果的检查与修正版。
> **用户脚本仍是 4.2.7；扩展单独为 1.0.1；没有 4.2.8。**

## 我检查出的问题（已修）

1. **考试页识别太窄**
   DeepSeek 的 `examScope()` 只认 `/exam/test/reVersionTestStartNew` 和 `/mooc2/exam/preview`。
   逐题考试常见的 `/exam-ans/exam/test/examcode/...` 会被判成“非考试页”，跨题自动继续和自动点下一题都不会出现。
   已改为识别：
   - `/exam-ans/exam/test`
   - `/exam-ans/exam/preview`
   - `/exam/test`
   - `/exam/preview`
   - `/mooc2/exam/preview`

2. **跨题作用域里混入了每题都会变的参数**
   DeepSeek 的 scope 包含 `examAnswerId`、`examcode`；如果下一题这两个值变化，`sessionStorage` 对不上，跨题自动继续会失效。
   已改为只用稳定的 `examId/testId/paperId/courseId/workId`，并把路径收敛到考试根路径。

3. **跨世界 `postMessage` 的 source 检查**
   `content.js` 和用户脚本桥都重新加了 `ev.source !== window`。在内容脚本隔离世界/Tampermonkey 沙箱里这个相等关系不保证，可能导致“时不时未连接”。
   已移除这两处严格 source 判断；仍然校验 `__zxExt === true` 和 `source` 字段。

4. **顶层路由没覆盖 `/exam-ans/exam/test`**
   DeepSeek 只在桥里认了这个路径，脚本启动路由仍只匹配 `/exam/test/reVersionTestStartNew`。这样侧栏能看到“已连接”，但页面上没有任务在跑。
   已把路由扩到 `/exam/test/`（含 `/exam-ans/exam/test`）和 `/exam-ans/exam/preview`。

5. **图片格式没有校验，导致 API 400 / 图片题暂停**
   DeepSeek 的 `readBlob()` 只排除了 video/audio，任何 `image/svg+xml`、`image/avif`、HTML 响应都会被转成 data URL 塞进 `image_url`，而接口只接受 png/jpeg/webp/gif。
   更糟的是 `callAI()` 把所有 HTTP 400 都当成 thinking 参数问题，连续重试，日志就会刷“服务拒绝 thinking”。
   已修：读取时校验 MIME；支持 `application/octet-stream, image/jpeg` 这种复合 Content-Type；只有 `application/octet-stream`/空类型时按文件头嗅探 PNG/JPEG/GIF/WebP/BMP/AVIF/SVG；SVG 走 PNG 转换；AVIF/BMP 等用 canvas 转 PNG；接口仍拒绝图片时去掉 image_url、关闭 thinking 后纯文字重试一次。
   图片不完整时不再暂停整题：`callAI()` 会降级为纯文字继续，自动答题链不会断。

6. **自动点下一题会误跳/连跳**
   DeepSeek 版本之后，我又加了 `.mark_table a` 全表文本扫描和多个回调各自的 2 秒定时器；前者可能点到题目导航/上一题，后者会在第二题还没作答时继续点“下一题”，表现就是 1→2→3→1→2 反复横跳。
   已收紧：优先在 `.nextDiv` / `.jb_btn` 内找下一题；找不到时只按“可见按钮文本以下一题开头”兜底；同一页面只允许一个待执行跳题定时器。
   我之前加的“当前题 DOM 是否已作答”检查会误判：截图里 C 已经选中，它却写“未检测到已作答”，把正确的自动跳题也拦了。已删除这个检查。
   “下一题”是页面底部普通 button、不在 `.nextDiv` 时，现在会扫描可见的按钮/链接，文本必须以“下一题/下一頁”开头，并用单页定时器锁住；这能点到底部蓝色“下一题”，又不会把题目导航里的数字当按钮。
7. **日志跨页丢失**
   `logger()` / `updateLogEntry()` 现在同时写入 `sessionStorage` 的 `zx-sidepanel-log-history`，`status` 优先返回这份历史（最多 400 条、16000 字符）。页面刷新/跳题后侧栏仍能看到上一页日志。

8. **全部题目完成后不自动停**
   整卷预览：`doExamPreview` 处理完 `TiMuList.length` 后调用 `zxAutoPauseDone()`。
   逐题页：`zxExamLooksFinished()` 检测页面完成文案/交卷按钮/题目导航最后一项 active；`toNextExam()` 在跳题前先判断，命中就设置 `ZhixingSetting.isPaused=true`、写日志、侧栏显示“已暂停”，不会继续自动跳题。

9. **保留 DeepSeek 已做对的部分**
   - 连接失败宽限（4 次失败才显示未连接）、重连按钮、onUpdated/onActivated 重探、单飞锁。
   - `autoContinue` + `resumeExam` 跨题恢复。
   - 侧栏 UI 的 `connHint`、跨题自动继续、自动点击下一题。

## 安装

1. 覆盖安装 `zhixing-4.2.7.user.js`（同版本不会自动更新，必须手动覆盖）。
2. 解压 `zhixing-sidepanel-1.0.1.zip` 到固定目录。
3. Edge 打开 `edge://extensions/` → 开发人员模式 → 加载解压缩的扩展 → 选直接包含 `manifest.json` 的目录。
4. 在扩展列表里点「重新加载」，再刷新学习通页面。
5. 打开侧栏，确认「已连接」。

## 使用

- 先点「开始当前任务」，侧栏会自动勾选「跨题自动继续」。
- 需要脚本自动翻页时，勾选「自动点击下一题」。
- 手动点「下一题」也可以：新页面连接后会自动继续。
- 暂停或取消「跨题自动继续」后，新页面不会再自动启动。

## 验证

- 39 项核心回归通过（`|z|`、空 Key、媒体、记录、canvas、callAI、push 等）。
- 新增桥测试通过：`/exam-ans` 识别、scope 不受 `examAnswerId` 变化影响、toggle、resume。
- 侧栏 UI 测试通过：状态渲染 + auto resume。
- 内容脚本测试通过：标记、隐藏、请求/响应桥。
- `node --check` 全部通过。
- 仍未在真实 Edge 里做端到端测试；沙箱无法启动 Edge 侧栏，需要你加载后确认视觉和实际考试页 DOM。

## 文件

- `zhixing-4.2.7.user.js`
- `zhixing-4.2.7-lite.user.js`
- `扩展-1.0.1/`（可直接加载的解压目录）
- `zhixing-sidepanel-1.0.1.zip`
