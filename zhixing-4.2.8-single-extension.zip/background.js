/* 知行单扩展：侧栏、页面脚本注入、GM 兼容代理。 */
'use strict';

try {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () { });
} catch (_) { }

const COURSE_RE = /^https?:\/\/(?:[^/]+\.)*(?:chaoxing\.com|xuexitong\.com|edu\.cn|org\.cn|ac\.cn|xueyinonline\.com|sslibrary\.com|neauce\.com|nbdlib\.cn|hnsyu\.net|qutjxjy\.cn|ynny\.cn|hnvist\.cn|fjlecb\.cn|gdhkmooc\.com|cugbonline\.cn|zjelib\.cn|cqrspx\.cn|zhihui-yun\.com|cqie\.cn|ccqmxx\.com|jxgmxy\.com|jnzyjsxy\.cn)(?::\d+)?\//i;

async function execute(tabId, files, world) {
  return chrome.scripting.executeScript({ target: { tabId: tabId }, files: files, world: world });
}

async function contentAlive(tabId) {
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'ISOLATED',
      func: function () { return !!(window.__zxContentBridgeLoaded); }
    });
    return !!(r && r[0] && r[0].result);
  } catch (_) { return false; }
}

async function ensureInjected(tabId) {
  if (!tabId) return { ok: false, error: 'no tabId' };
  let tab = null;
  try { tab = await chrome.tabs.get(tabId); } catch (_) { return { ok: false, error: 'tab gone' }; }
  if (!tab || !/^https?:/i.test(tab.url || '')) return { ok: false, error: 'not http' };
  if (!COURSE_RE.test(tab.url || '')) return { ok: false, error: 'not course' };

  // 先确认隔离世界桥是否已在（manifest 注入或上一轮脚本注入）；不在才补，避免重复监听。
  if (!(await contentAlive(tabId))) {
    try { await execute(tabId, ['content.js'], 'ISOLATED'); } catch (e) { console.warn('[知行] content 注入失败', e); }
  }

  // GM 配置走 chrome.storage，跨学习通子域保留；注入到 MAIN world 的内存缓存，供同步 GM_getValue 读取。
  let stored = {};
  try { stored = await chrome.storage.local.get(null); } catch (_) { }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: function (data) { window.__zxGmCache = data || {}; },
      args: [stored]
    });
  } catch (e) { console.warn('[知行] GM 缓存注入失败', e); }

  try { await execute(tabId, ['userscript-shim.js'], 'MAIN'); } catch (e) { console.warn('[知行] shim 注入失败', e); }
  try { await execute(tabId, ['userscript-main.js'], 'MAIN'); } catch (e) { console.warn('[知行] 主脚本注入失败', e); }
  return { ok: true, url: tab.url };
}

chrome.action.onClicked.addListener(function (tab) {
  if (!tab || !tab.id) return;
  // sidePanel.open 必须在用户手势的同步栈里调用；先打开，再异步注入，否则点击图标会没反应。
  try {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(function (e) { console.warn('[知行] 打开侧栏失败', e); });
  } catch (e) {
    console.warn('[知行] 打开侧栏异常', e);
  }
  ensureInjected(tab.id).catch(function (e) { console.warn('[知行] 注入失败', e); });
});


function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function gmFetch(req) {
  req = req || {};
  const controller = new AbortController();
  const timeout = Number(req.timeout) || 120000;
  const timer = setTimeout(function () { controller.abort(); }, timeout);
  try {
    const headers = req.headers || {};
    const body = (typeof req.data === 'string' || req.data == null) ? req.data : JSON.stringify(req.data);
    const res = await fetch(req.url, {
      method: req.method || 'GET',
      headers: headers,
      body: body,
      credentials: 'include',
      redirect: 'follow',
      signal: controller.signal
    });
    const contentType = res.headers.get('content-type') || '';
    const buf = await res.arrayBuffer();
    const wantedBlob = req.responseType === 'blob';
    const wantedBuffer = req.responseType === 'arraybuffer';
    const text = wantedBlob ? '' : new TextDecoder('utf-8').decode(buf);
    const h = {};
    res.headers.forEach(function (value, key) { h[key] = value; });
    return {
      ok: true, status: res.status, statusText: res.statusText,
      headers: h, text: text,
      base64: wantedBlob ? arrayBufferToBase64(buf) : '',
      arrayBuffer: wantedBuffer ? arrayBufferToBase64(buf) : '',
      contentType: contentType, url: res.url
    };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e), timeout: e && e.name === 'AbortError' };
  } finally {
    clearTimeout(timer);
  }
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'zxEnsureInjected') {
    const tabId = (sender && sender.tab && sender.tab.id) || msg.tabId;
    ensureInjected(tabId).then(function (r) { sendResponse(r); }).catch(function (e) { sendResponse({ ok: false, error: String(e) }); });
    return true;
  }
  if (msg.type === 'zxGmFetch') {
    gmFetch(msg.req).then(function (r) { sendResponse(r); }).catch(function (e) { sendResponse({ ok: false, error: String(e) }); });
    return true;
  }
  if (msg.type === 'zxGmSet') {
    try {
      if (msg.deleted) chrome.storage.local.remove(String(msg.key));
      else {
        const data = {};
        data[String(msg.key)] = msg.value;
        chrome.storage.local.set(data);
      }
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }
});
