/* 知行单扩展：MAIN world 的 GM_* 兼容层。 */
(function () {
  'use strict';

  var cache = {};
  try { cache = window.__zxGmCache || {}; } catch (_) { }
  try { delete window.__zxGmCache; } catch (_) { }

  function has(k) { return Object.prototype.hasOwnProperty.call(cache, k); }

  window.GM_getValue = function (key, def) {
    return has(String(key)) ? cache[String(key)] : def;
  };
  window.GM_setValue = function (key, value) {
    var k = String(key);
    cache[k] = value;
    try { window.postMessage({ __zxGmSet: true, key: k, value: value }, '*'); } catch (_) { }
  };
  window.GM_deleteValue = function (key) {
    var k = String(key);
    try { delete cache[k]; } catch (_) { }
    try { window.postMessage({ __zxGmSet: true, key: k, deleted: true }, '*'); } catch (_) { }
  };
  window.GM_listValues = function () { return Object.keys(cache); };
  window.GM_info = { script: { version: '4.2.8', name: '知行 · 网课助手' } };
  window.unsafeWindow = window;

  var seq = 0;
  var pending = {};

  function b64ToBytes(b64) {
    var bin = atob(String(b64 || ''));
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function headerString(h) {
    try {
      return Object.keys(h || {}).map(function (k) { return k + ': ' + h[k]; }).join('\r\n');
    } catch (_) { return ''; }
  }
  function finish(id, ok, data) {
    var p = pending[id];
    if (!p) return;
    delete pending[id];
    if (p.timer) clearTimeout(p.timer);
    var d = p.details;
    if (!ok) {
      try {
        if (data && data.timeout && d.ontimeout) d.ontimeout(data);
        else if (d.onerror) d.onerror(data);
      } catch (_) { }
      return;
    }
    try {
      var status = Number(data.status) || 0;
      var response = data.text || '';
      if (d.responseType === 'blob') {
        response = new Blob([b64ToBytes(data.base64 || '')], { type: data.contentType || 'application/octet-stream' });
      } else if (d.responseType === 'arraybuffer') {
        response = b64ToBytes(data.arrayBuffer || '').buffer;
      }
      if (d.onload) d.onload({
        status: status,
        statusText: data.statusText || '',
        responseText: data.text || '',
        response: response,
        responseHeaders: headerString(data.headers),
        finalUrl: data.url || ''
      });
    } catch (_) { }
  }

  window.GM_xmlhttpRequest = function (details) {
    details = details || {};
    var id = 'gm' + Date.now().toString(36) + '-' + (++seq);
    var req = {
      method: details.method || 'GET',
      url: details.url,
      headers: details.headers || {},
      data: details.data == null ? null : (typeof details.data === 'string' ? details.data : JSON.stringify(details.data)),
      responseType: details.responseType || 'text',
      timeout: Number(details.timeout) || 120000
    };
    var timer = null;
    if (details.timeout) {
      timer = setTimeout(function () { finish(id, false, { timeout: true }); }, Number(details.timeout));
    }
    pending[id] = { details: details, timer: timer };
    try {
      window.postMessage({ __zxGmRequest: true, id: id, req: req }, '*');
    } catch (e) {
      finish(id, false, { error: String(e) });
    }
    return {
      abort: function () {
        finish(id, false, { error: 'aborted' });
        var d = details;
        try { if (d.onabort) d.onabort({ status: 0, statusText: 'aborted' }); } catch (_) { }
      }
    };
  };

  window.addEventListener('message', function (ev) {
    var m = ev.data;
    if (!m || m.__zxGmResult !== true) return;
    var p = pending[m.id];
    if (!p) return;
    var data = m.resp || { ok: false, error: 'empty response' };
    finish(m.id, data.ok === true, data);
  });
})();
