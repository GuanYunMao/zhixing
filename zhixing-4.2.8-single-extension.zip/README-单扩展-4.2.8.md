# 知行 · 网课助手 4.2.8 单扩展版

> 4.2.8 单扩展：页面逻辑、原生 `chrome.sidePanel` 侧栏、控制面板全部在一个 Edge 扩展里。
> **不需要 Tampermonkey，不需要单独安装 `zhixing.user.js`。** 仍需要开发者模式加载本地扩展；Edge 自装扩展没有免开发者模式的本地安装方式。

## 安装

1. 先在 `edge://extensions` 停用/删除旧的两件套扩展。
2. 在 Tampermonkey/脚本猫里停用或删除 4.2.8 用户脚本，避免页面里跑两份逻辑。
3. 解压 `zhixing-4.2.8-single-extension.zip` 到固定目录，确保 `manifest.json` 直接位于该目录。
4. 打开 `edge://extensions/`，开启「开发人员模式」。
5. 「加载解压缩的扩展」→ 选择那个含 `manifest.json` 的目录。
6. 刷新所有学习通标签页；打开扩展图标，右侧侧栏应显示「已连接」。

> 扩展重新加载后，旧标签页建议刷新一次；单击扩展图标会先打开侧栏，再异步注入页面脚本。

## 配置迁移

旧版把 API Key 存在 Tampermonkey 的 `GM_*` 存储里，这套存储无法直接跨扩展读取。单扩展版改用 `chrome.storage.local`：

- 打开侧栏 → API 设置 → 重新填地址/Key/模型 → 保存并测试。
- 配置由侧栏直接写入 `chrome.storage.local`，会跨学习通子域保留；自动下一题/刷新页面后不需要重配。
- Key 输入框留空保存会保留已存 Key；点「显示」会从扩展存储读取并填入，不再是一个空输入框的空动作。
- 页面内旧面板被隐藏，不需要再点页面里的设置。
- 选项区固定三行：跨题自动继续、自动点击下一题、跳过已做题；不支持的项只禁用，不再上下跳位。

## 实现

- `background.js`：action 打开 sidePanel；向当前学习通页面注入 `content.js`、`userscript-shim.js`、`userscript-main.js`；代理 `GM_xmlhttpRequest`；保存 GM 配置到 `chrome.storage.local`。
- `content.js`：`document_start` 标记页面、隐藏旧面板、side panel 消息桥、GM 请求/存储桥。
- `userscript-shim.js`：MAIN world 的 `GM_getValue` / `GM_setValue` / `GM_deleteValue` / `GM_xmlhttpRequest` / `GM_info` / `unsafeWindow` 兼容层。
- `userscript-main.js`：原 4.2.8 用户脚本，由扩展注入 MAIN world；保留原有自动答题、图片、日志、自动跳题、自动暂停逻辑。
- `sidepanel.*`：原生侧栏 UI；不再区分“用户脚本/侧栏扩展”，也不需要 Tampermonkey。

## 限制

- 仍必须用开发者模式加载；Edge 不允许自签 `.crx` 直接安装。上架 Edge 商店需要开发者账号/审核，这类自动化脚本大概率不会通过，我无法保证。
- `GM_*` 兼容层在页面 MAIN world 运行，API Key 会在页面内存缓存中出现；配置本身存扩展 `chrome.storage.local`，不写页面 localStorage。能接受这个前提再装。
- `GM_xmlhttpRequest` 走扩展后台 `fetch`，部分站点对 Referer/Cookie 的校验可能和 Tampermonkey 不同；图片/接口若失败，日志会指出。
- 真实学习通页面、iframe、特殊公式仍需真机验证；沙箱无法启动带界面的 Edge。
- 不改 GitHub `main`/Pages，除非明确要求发布这版。
