/* 知行单扩展：页面标记、旧面板隐藏、side panel 桥、GM_xmlhttpRequest 代理。 */
(function () {
  'use strict';
  if (window.__zxContentBridgeLoaded) return;
  window.__zxContentBridgeLoaded = true;

  function mark() {
    try {
      if (document.documentElement) document.documentElement.setAttribute('data-zx-ext', '1');
    } catch (_) { }
  }
  mark();

  var hideCss = [
    'html[data-zx-ext="1"] body #ne-21box.zx421-sidebar,',
    'html[data-zx-ext="1"] body #ne-21box,',
    'html[data-zx-ext="1"] body #ne21Ball,',
    'html[data-zx-ext="1"] body #zx421Divider {',
    '  display:none !important;',
    '  visibility:hidden !important;',
    '}'
  ].join('\n');

  function ensureStyle() {
    try {
      mark();
      if (document.getElementById('zx-ext-hide-panel')) return;
      var style = document.createElement('style');
      style.id = 'zx-ext-hide-panel';
      style.textContent = hideCss;
      (document.head || document.documentElement).appendChild(style);
    } catch (_) { }
  }
  ensureStyle();
  window.setInterval(ensureStyle, 1500);


  var pending = new Map();
  var seq = 0;

  function makeId() {
    seq += 1;
    return 'zx' + Date.now().toString(36) + '-' + seq;
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || msg.source !== 'zx-sidepanel') return;
    var id = msg.id || makeId();
    var timer = setTimeout(function () {
      if (!pending.has(id)) return;
      pending.delete(id);
      try { sendResponse({ ok: false, error: '页面脚本尚未注入或仍在加载，请重试。' }); } catch (_) { }
    }, 5000);
    pending.set(id, function (result) {
      clearTimeout(timer);
      pending.delete(id);
      try { sendResponse(result); } catch (_) { }
    });
    try {
      window.postMessage({ __zxExt: true, source: 'zx-sidepanel', id: id, cmd: msg.cmd, payload: msg.payload }, '*');
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      try { sendResponse({ ok: false, error: '无法向页面脚本发送消息' }); } catch (_) { }
    }
    return true;
  });

  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (!d || d.__zxExt !== true || d.source !== 'zx-page') return;
    // 有旧 Tampermonkey 脚本同时存在时，只接受单扩展主脚本的响应，避免两个桥抢答。
    if (d.ok && (!d.data || d.data.bridgeVersion !== '4.2.8-single')) return;
    var done = pending.get(d.id);
    if (done) done(d);
  });

  // 页面 shim 的 GM_xmlhttpRequest / GM_setValue 代理。
  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (!d) return;
    if (d.__zxGmRequest === true) {
      try {
        chrome.runtime.sendMessage({ type: 'zxGmFetch', req: d.req }, function (resp) {
          var out = resp || { ok: false, error: '后台没有响应' };
          try { window.postMessage({ __zxGmResult: true, id: d.id, resp: out }, '*'); } catch (_) { }
        });
      } catch (e) {
        try { window.postMessage({ __zxGmResult: true, id: d.id, resp: { ok: false, error: String(e) } }, '*'); } catch (_) { }
      }
      return;
    }
    if (d.__zxGmSet === true) {
      try {
        chrome.runtime.sendMessage({ type: 'zxGmSet', key: d.key, value: d.value, deleted: !!d.deleted }, function () { });
      } catch (_) { }
    }
  });
})();
